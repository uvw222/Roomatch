//./lib/mongodb.ts
import mongoose from "mongoose"

// This creates a custom global type only for this script
let cached = (global as any).mongoose

if (!cached) {
  cached = (global as any).mongoose = { conn: null, promise: null }
}

async function connectToDatabase() {
  const MONGODB_URI = process.env.MONGODB_URI;
  if (!MONGODB_URI) {
  throw new Error("Please define the MONGODB_URI environment variable in .env.local")
}
  if (cached.conn) return cached.conn

  if (!cached.promise) {
    cached.promise = mongoose.connect(MONGODB_URI!, {
      dbName: "roomatch", 
    })
  }

  cached.conn = await cached.promise
  return cached.conn
}

export default connectToDatabase
